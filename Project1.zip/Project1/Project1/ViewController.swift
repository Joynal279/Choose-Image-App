//
//  ViewController.swift
//  Project1
//
//  Created by JOHN DARK on 31/01/20.
//  Copyright © 2020 iFive. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
     
//        print(pictures)
    }
    


}

